/*
* KobukiNavigationStatechart.c
*
*/

#include "kobukiNavigationStatechart.h"
#include <math.h>
#include <stdlib.h>
#include <stdio.h>


// Program States
typedef enum{
	INITIAL = 0,						// Initial state
	PAUSE_WAIT_BUTTON_RELEASE,			// Paused; pause button pressed down, wait until released before detecting next press
	UNPAUSE_WAIT_BUTTON_PRESS,			// Paused; wait for pause button to be pressed
	UNPAUSE_WAIT_BUTTON_RELEASE,		// Paused; pause button pressed down, wait until released before returning to previous state
	DRIVE,								// Drive straight
	TURN_LEFT_25,							// Turn left
	TURN_LEFT_75,
	TURN_RIGHT_25,							// Turn right
	TURN_RIGHT_75,
	TURN_180,
	REORIENT_RIGHT,
	REORIENT_LEFT,
	CLIFF_AVOIDANCE,
	HILL,
	HILL_REORIENT_LEFT,
	HILL_REORIENT_RIGHT,
	ASCEND,
	DESCEND,
	TURN_AROUND,
	STOP
} robotState_t;

#define DEG_PER_RAD			(180.0 / M_PI)		// degrees per radian
#define RAD_PER_DEG			(M_PI / 180.0)		// radians per degree

void KobukiNavigationStatechart(
	const int16_t 				maxWheelSpeed,
	const int32_t 				netDistance,
	const int32_t 				netAngle,
	const KobukiSensors_t		sensors,
	const accelerometer_t		accelAxes,
	int16_t * const 			pRightWheelSpeed,
	int16_t * const 			pLeftWheelSpeed,
	const bool					isSimulator
	){

	// local state
	static robotState_t 		state = INITIAL;				// current program state
	static robotState_t			unpausedState = DRIVE;			// state history for pause region
	static int32_t				distanceAtManeuverStart = 0;	// distance robot had travelled when a maneuver begins, in mm
	static int32_t				angleAtManeuverStart = 0;		// angle through which the robot had turned when a maneuver begins, in deg

	// outputs
	int16_t						leftWheelSpeed = 0;				// speed of the left wheel, in mm/s
	int16_t						rightWheelSpeed = 0;			// speed of the right wheel, in mm/s

	// more local state for hill climb
	static bool                 isAscend = 0;
	static bool                 isDescend = 0;
	static int32_t              hillOrientation = 0;
	static double               accel_threshold = 0.06;
	static int32_t 				test = 0;



	//*****************************************************
	// state data - process inputs                        *
	//*****************************************************



	if (state == INITIAL
		|| state == PAUSE_WAIT_BUTTON_RELEASE
		|| state == UNPAUSE_WAIT_BUTTON_PRESS
		|| state == UNPAUSE_WAIT_BUTTON_RELEASE
		|| sensors.buttons.B0				// pause button
		){
		switch (state){
		case INITIAL:
			// set state data that may change between simulation and real-world
			if (isSimulator){
			}
			else{
			}
			state = UNPAUSE_WAIT_BUTTON_PRESS; // place into pause state
			break;
		case PAUSE_WAIT_BUTTON_RELEASE:
			// remain in this state until released before detecting next press
			if (!sensors.buttons.B0){
				state = UNPAUSE_WAIT_BUTTON_PRESS;
			}
			break;
		case UNPAUSE_WAIT_BUTTON_RELEASE:
			// user pressed 'pause' button to return to previous state
			if (!sensors.buttons.B0){
				if ((abs(accelAxes.x) < accel_threshold) && (abs(accelAxes.y) < accel_threshold)) {
					unpausedState = DRIVE;
				}
				else {
					printf("%f", accelAxes.x);
					unpausedState = HILL;
				}
				state = unpausedState;
			}
			break;
		case UNPAUSE_WAIT_BUTTON_PRESS:
			// remain in this state until user presses 'pause' button
			if (sensors.buttons.B0){
				state = UNPAUSE_WAIT_BUTTON_RELEASE;
			}
			break;
		default:
			// must be in run region, and pause button has been pressed
			unpausedState = state;
			state = PAUSE_WAIT_BUTTON_RELEASE;
			break;
		}
	}
	//*************************************
	// state transition - run region      *
	//*************************************
	else if (state == HILL) {
		printf("%d\n",state);
		// start reorienting until x is close to 0
		if (abs(accelAxes.x) < accel_threshold) {
			hillOrientation = netAngle;
			isAscend = 1;
			state = ASCEND;
			printf("%f", accelAxes.x);
		}

	}
	else if (state == TURN_AROUND) {
		printf("%d\n",state);
			int modulo_angle;
		int currAngle = netAngle - hillOrientation;
		if (currAngle % 360 < 0) {
			modulo_angle = currAngle % 360 + 360;
		}
		else {
			modulo_angle = currAngle % 360;
		}
		if (modulo_angle <= 2 || modulo_angle >= 358) {
			isDescend = 1;
			state = DESCEND;
		}
	}
	else if (state == ASCEND) {
		printf("%d\n",state);
		if (sensors.bumps_wheelDrops.bumpCenter && sensors.bumps_wheelDrops.bumpRight) {
			distanceAtManeuverStart = netDistance;
			angleAtManeuverStart = netAngle;
			state = TURN_LEFT_75;
		}
		else if (sensors.bumps_wheelDrops.bumpCenter) {
			distanceAtManeuverStart = netDistance;
			angleAtManeuverStart = netAngle;
			state = TURN_RIGHT_75;
		}
		else if (sensors.bumps_wheelDrops.bumpLeft) {
			distanceAtManeuverStart = netDistance;
			angleAtManeuverStart = netAngle;
			state = TURN_RIGHT_25;
		}
		else if (sensors.bumps_wheelDrops.bumpRight) {
			distanceAtManeuverStart = netDistance;
			angleAtManeuverStart = netAngle;
			state = TURN_LEFT_25;
		}
		else if (sensors.cliffCenter || sensors.cliffRight || sensors.cliffLeft) {
//			distanceAtManeuverStart = netDistance;
//			angleAtManeuverStart = netAngle;
//			// check if reached end at the top somewhere here
//			int modulo_angle;
//			int currAngle = netAngle - hillOrientation;
//			if (currAngle % 360 < 0) {
//				modulo_angle = currAngle % 360 + 360;
//			}
//			else {
//				modulo_angle = currAngle % 360;
//			}
			if ((abs(accelAxes.x) < accel_threshold) && (abs(accelAxes.y) < accel_threshold)) {
				state = TURN_AROUND;
				hillOrientation = hillOrientation + 180;
				isAscend = 0;

			}
			else {
				state = CLIFF_AVOIDANCE;
			}
		}
		else if (abs(accelAxes.y) > accel_threshold) {
			state = HILL;
		}
		else if (abs(netDistance - distanceAtManeuverStart) >= 50) {
			int modulo_angle;
			int currAngle = netAngle - hillOrientation;

			if (currAngle % 360 < 0) {
				modulo_angle = currAngle % 360 + 360;
			}
			else {
				modulo_angle = currAngle % 360;
			}
			if (modulo_angle > 2 && modulo_angle < 358) {
				distanceAtManeuverStart = netDistance;
				angleAtManeuverStart = netAngle;
				if (modulo_angle >= 180) {
					state = HILL_REORIENT_LEFT;
				}
				else {
					state = HILL_REORIENT_RIGHT;
				}
			}

		}

	}
	else if (state == DESCEND) {
		printf("%d\n",state);

		if ((abs(accelAxes.x) < accel_threshold) && (abs(accelAxes.y) < accel_threshold)) {
			state = STOP;
		}
		else if (sensors.bumps_wheelDrops.bumpCenter && sensors.bumps_wheelDrops.bumpRight) {
			distanceAtManeuverStart = netDistance;
			angleAtManeuverStart = netAngle;
			state = TURN_LEFT_75;
		}
		else if (sensors.bumps_wheelDrops.bumpCenter) {
			distanceAtManeuverStart = netDistance;
			angleAtManeuverStart = netAngle;
			state = TURN_RIGHT_75;
		}
		else if (sensors.bumps_wheelDrops.bumpLeft) {
			distanceAtManeuverStart = netDistance;
			angleAtManeuverStart = netAngle;
			state = TURN_RIGHT_25;
		}
		else if (sensors.bumps_wheelDrops.bumpRight) {
			distanceAtManeuverStart = netDistance;
			angleAtManeuverStart = netAngle;
			state = TURN_LEFT_25;
		}
		else if (sensors.cliffCenter || sensors.cliffRight || sensors.cliffLeft) {
			distanceAtManeuverStart = netDistance;
			angleAtManeuverStart = netAngle;
			state = CLIFF_AVOIDANCE;
		}
		else if (abs(netDistance - distanceAtManeuverStart) >= 50) {
			int modulo_angle;
			int currAngle = netAngle - hillOrientation;

			if (currAngle % 360 < 0) {
				modulo_angle = currAngle % 360 + 360;
			}
			else {
				modulo_angle = currAngle % 360;
			}
			if (modulo_angle > 2 && modulo_angle < 358) {
				distanceAtManeuverStart = netDistance;
				angleAtManeuverStart = netAngle;
				if (modulo_angle >= 180) {
					state = HILL_REORIENT_LEFT;
				}
				else {
					state = HILL_REORIENT_RIGHT;
				}
			}

		}

	}
	else if (state == STOP) {
		printf("You are in State %d, x = %f, y = %f, z = %f\n",state, accelAxes.x, accelAxes.y, accelAxes.z);
		state = INITIAL;
	}
	else if (state == DRIVE) {
		printf("%d\n", test);

		printf("You are in State %d, x = %f, y = %f, z = %f\n",state, accelAxes.x, accelAxes.y, accelAxes.z);

		if (sensors.bumps_wheelDrops.bumpCenter && sensors.bumps_wheelDrops.bumpRight) {
			distanceAtManeuverStart = netDistance;
			angleAtManeuverStart = netAngle;
			state = TURN_LEFT_75;
		}
		else if (sensors.bumps_wheelDrops.bumpCenter) {
			distanceAtManeuverStart = netDistance;
			angleAtManeuverStart = netAngle;
			state = TURN_RIGHT_75;
		}
		else if (sensors.bumps_wheelDrops.bumpLeft) {
			distanceAtManeuverStart = netDistance;
			angleAtManeuverStart = netAngle;
			state = TURN_RIGHT_25;
		}
		else if (sensors.bumps_wheelDrops.bumpRight) {
			distanceAtManeuverStart = netDistance;
			angleAtManeuverStart = netAngle;
			state = TURN_LEFT_25;
		}
		//else if (((abs(accelAxes.x) > accel_threshold) || (abs(accelAxes.y) > accel_threshold))) {
		else if (abs(accelAxes.z - 1) > .1 ){

			state = HILL;
			printf("You are in State %d, x = %f, y = %f, z = %f\n",state, accelAxes.x, accelAxes.y, accelAxes.z);
		}
		else if (sensors.cliffCenter || sensors.cliffRight || sensors.cliffLeft) {
			distanceAtManeuverStart = netDistance;
			angleAtManeuverStart = netAngle;
			state = CLIFF_AVOIDANCE;
		}
		else if (abs(netDistance - distanceAtManeuverStart) >= 500) {
			int modulo_angle;
			if (netAngle % 360 < 0) {
				modulo_angle = netAngle % 360 + 360;
			}
			else {
				modulo_angle = netAngle % 360;
			}
			if (modulo_angle > 2 && modulo_angle < 358) {
				distanceAtManeuverStart = netDistance;
				angleAtManeuverStart = netAngle;
				if (modulo_angle >= 180) {
					state = REORIENT_LEFT;
				}
				else {
					state = REORIENT_RIGHT;
				}
			}

		}

	}
	else if (state == CLIFF_AVOIDANCE) {
		if (sensors.cliffCenter) {
			distanceAtManeuverStart = netDistance;
			angleAtManeuverStart = netAngle;
			state = TURN_180;
		}
		else if (sensors.cliffRight) {
			distanceAtManeuverStart = netDistance;
			angleAtManeuverStart = netAngle;
			state = TURN_LEFT_75;
		}
		else if (sensors.cliffLeft) {
			distanceAtManeuverStart = netDistance;
			angleAtManeuverStart = netAngle;
			state = TURN_RIGHT_75;
		}
	}
	else if (state == HILL_REORIENT_RIGHT || state == HILL_REORIENT_LEFT) {
		int modulo_angle;
		int currAngle = netAngle - hillOrientation;

		if (currAngle % 360 < 0) {
			modulo_angle = currAngle % 360 + 360;
		}
		else {
			modulo_angle = currAngle % 360;
		}

		if (modulo_angle <= 2 || modulo_angle >= 358) {
			angleAtManeuverStart = netAngle;
			distanceAtManeuverStart = netDistance;
			if (isAscend) {
				state = ASCEND;
				printf("You are in State %d, x = %f, y = %f, z = %f\n",state, accelAxes.x, accelAxes.y, accelAxes.z);
			}
			else {
				state = DESCEND;
				printf("You are in State %d, x = %f, y = %f, z = %f\n",state, accelAxes.x, accelAxes.y, accelAxes.z);
			}
		}
	}
	else if (state == REORIENT_RIGHT || state == REORIENT_LEFT) {
		int modulo_angle;
		if (netAngle % 360 < 0) {
			modulo_angle = netAngle % 360 + 360;
		}
		else {
			modulo_angle = netAngle % 360;
		}

		if (modulo_angle <= 2 || modulo_angle >= 358) {
			angleAtManeuverStart = netAngle;
			distanceAtManeuverStart = netDistance;
			state = DRIVE;
		}
	}
	else if (state == TURN_LEFT_25 && abs(netAngle - angleAtManeuverStart) >= 25) {
		angleAtManeuverStart = netAngle;
		distanceAtManeuverStart = netDistance;
		if (isAscend) {
			state = ASCEND;
		}
		else if (isDescend) {
			state = DESCEND;
		}
		else {
			state = DRIVE;
		}
	}
	else if (state == TURN_LEFT_75 && abs(netAngle - angleAtManeuverStart) >= 75) {
		angleAtManeuverStart = netAngle;
		distanceAtManeuverStart = netDistance;
		if (isAscend) {
			state = ASCEND;
		}
		else if (isDescend) {
			state = DESCEND;
		}
		else {
			state = DRIVE;
		}
	}
	else if (state == TURN_RIGHT_25 && abs(netAngle - angleAtManeuverStart) >= 25) {
		angleAtManeuverStart = netAngle;
		distanceAtManeuverStart = netDistance;
		if (isAscend) {
			state = ASCEND;
		}
		else if (isDescend) {
			state = DESCEND;
		}
		else {
			state = DRIVE;
		}
	}
	else if (state == TURN_RIGHT_75 && abs(netAngle - angleAtManeuverStart) >= 75) {
		angleAtManeuverStart = netAngle;
		distanceAtManeuverStart = netDistance;
		if (isAscend) {
			state = ASCEND;
		}
		else if (isDescend) {
			state = DESCEND;
		}
		else {
			state = DRIVE;
		}
	}
	else if (state == TURN_180 && abs(netAngle - angleAtManeuverStart) >= 180) {
		angleAtManeuverStart = netAngle;
		distanceAtManeuverStart = netDistance;
		state = DRIVE;
	}
	// else, no transitions are taken

	//*****************
	//* state actions *
	//*****************
	switch (state){
	case INITIAL:
	case PAUSE_WAIT_BUTTON_RELEASE:
	case UNPAUSE_WAIT_BUTTON_PRESS:
	case UNPAUSE_WAIT_BUTTON_RELEASE:
		// in pause mode, robot should be stopped
		leftWheelSpeed = rightWheelSpeed = 0;
		break;

	case DRIVE:
		// full speed ahead!
		leftWheelSpeed = rightWheelSpeed = 100;
		break;
	case TURN_RIGHT_75:
		leftWheelSpeed = 100;
		rightWheelSpeed = -leftWheelSpeed;
		break;
	case TURN_RIGHT_25:
		leftWheelSpeed = 100;
		rightWheelSpeed = -leftWheelSpeed;
		break;
	case TURN_LEFT_75:
		rightWheelSpeed = 100;
		leftWheelSpeed = -rightWheelSpeed;
		break;
	case TURN_LEFT_25:
		rightWheelSpeed = 100;
		leftWheelSpeed = -rightWheelSpeed;
		break;
	case TURN_180:
		leftWheelSpeed = 100;
		rightWheelSpeed = -leftWheelSpeed;
		break;
	case REORIENT_RIGHT:
		leftWheelSpeed = 100;
		rightWheelSpeed = -leftWheelSpeed;
		break;
	case REORIENT_LEFT:
		rightWheelSpeed = 100;
		leftWheelSpeed = -rightWheelSpeed;
		break;
	case HILL:
		leftWheelSpeed = 100;
		rightWheelSpeed = -leftWheelSpeed;
		break;
	case HILL_REORIENT_RIGHT:
		leftWheelSpeed = 100;
		rightWheelSpeed = -leftWheelSpeed;
		break;
	case HILL_REORIENT_LEFT:
		rightWheelSpeed = 100;
		leftWheelSpeed = -rightWheelSpeed;
		break;
	case ASCEND:
		leftWheelSpeed = rightWheelSpeed = 100;
		break;
	case DESCEND:
		leftWheelSpeed = rightWheelSpeed = 100;
		break;
	case TURN_AROUND:
		leftWheelSpeed = 100;
		rightWheelSpeed = -leftWheelSpeed;
		break;
	default:
		// Unknown state
		leftWheelSpeed = rightWheelSpeed = 0;
		break;
	}



	*pLeftWheelSpeed = leftWheelSpeed;
	*pRightWheelSpeed = rightWheelSpeed;

	fflush(stdout);
}

